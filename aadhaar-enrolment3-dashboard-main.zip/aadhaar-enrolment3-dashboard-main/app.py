# ================== IMPORTS ==================
import streamlit as st
import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import seaborn as sns

from sklearn.cluster import KMeans
from sklearn.preprocessing import StandardScaler
from sklearn.linear_model import LinearRegression
from statsmodels.tsa.arima.model import ARIMA

# ================== PAGE CONFIG ==================
st.set_page_config(
    page_title="Aadhaar Enrolment Intelligence System",
    layout="wide",
    initial_sidebar_state="expanded"
)

st.title("🇮🇳 Aadhaar Enrolment Intelligence System")
st.caption("Government of India | Data Science & ML Analytics Platform")

# ================== DATA LOADING & CLEANING ==================
@st.cache_data(show_spinner=True)
def load_data():
    df = pd.read_csv("aadhaar_clean_states.csv")

    for col in ["state", "district"]:
        if col in df.columns:
            df[col] = df[col].astype(str).str.strip().str.title()

    df["date"] = pd.to_datetime(df["date"], errors="coerce", dayfirst=True)
    df = df.dropna(subset=["date"])

    subset_cols = [c for c in ["state", "district", "date"] if c in df.columns]
    df = df.drop_duplicates(subset=subset_cols)

    def find_col(keys):
        for c in df.columns:
            name = c.lower().replace("_", "").replace("-", "")
            if all(k in name for k in keys):
                return c
        return None

    age_0_5 = find_col(["0", "5"])
    age_5_17 = find_col(["5", "17"])
    age_18p = find_col(["18"])

    if not all([age_0_5, age_5_17, age_18p]):
        st.error("❌ Required age-wise columns not found")
        st.stop()

    df = df.rename(columns={
        age_0_5: "age_0_5",
        age_5_17: "age_5_17",
        age_18p: "age_18_plus"
    })

    for c in ["age_0_5", "age_5_17", "age_18_plus"]:
        df[c] = pd.to_numeric(df[c], errors="coerce").fillna(0)

    df["total"] = df["age_0_5"] + df["age_5_17"] + df["age_18_plus"]

    return df[df["total"] > 0]

df = load_data()

# ================== TABS ==================
tab1, tab2 = st.tabs(["📊 Analytics Dashboard", "🧪 Data Quality Report"])

# ================== TAB 1 ==================
with tab1:
    st.sidebar.header("🔍 Filters")
    state = st.sidebar.selectbox("Select State", sorted(df["state"].unique()))
    df_state = df[df["state"] == state]

    st.subheader(f"📍 State: {state}")

    c1, c2, c3 = st.columns(3)
    c1.metric("👥 Total Enrolments", f"{int(df_state.total.sum()):,}")
    c2.metric("👶 Children (0–5)", f"{int(df_state.age_0_5.sum()):,}")
    c3.metric("🧑 Adults (18+)", f"{int(df_state.age_18_plus.sum()):,}")

    st.divider()

    # ================== PAST • PRESENT • FUTURE TREND ==================
    st.subheader("📈 Aadhaar Enrolment Trends: Past • Present • Future")

    daily = (
        df_state
        .groupby(pd.Grouper(key="date", freq="D"))["total"]
        .sum()
    )

    monthly = (
        daily
        .resample("MS")
        .sum()
        .asfreq("MS", fill_value=0)
        .sort_index()
    )

    forecast = None
    method = "ML Trend Projection"

    if monthly.nunique() > 3 and len(monthly) >= 12:
        try:
            model = ARIMA(monthly, order=(1, 1, 1))
            fit = model.fit()
            forecast = fit.forecast(6)
            method = "ARIMA"
        except:
            forecast = None

    if forecast is None:
        X = np.arange(len(monthly)).reshape(-1, 1)
        y = monthly.values
        lr = LinearRegression()
        lr.fit(X, y)
        future_X = np.arange(len(monthly), len(monthly) + 6).reshape(-1, 1)
        forecast = lr.predict(future_X)
        forecast = pd.Series(
            forecast,
            index=pd.date_range(monthly.index[-1], periods=7, freq="MS")[1:]
        )

    fig, ax = plt.subplots(figsize=(12, 5))
    ax.plot(monthly.index, monthly.values, label="Past", linewidth=2)
    ax.scatter(monthly.index[-1], monthly.values[-1], s=80, color="black", label="Present")
    ax.plot(forecast.index, forecast.values, "--", color="red", label="Future")
    ax.axvspan(forecast.index[0], forecast.index[-1], color="red", alpha=0.1)
    ax.set_title(f"Past–Present–Future Trend ({method})")
    ax.legend()
    ax.grid(alpha=0.3)
    st.pyplot(fig, use_container_width=True)

    # ================== INSIGHTS ==================
    st.subheader("📌 Key Insights")

    latest = monthly.iloc[-1]
    previous = monthly.iloc[-2] if len(monthly) > 1 else latest
    growth = ((latest - previous) / previous * 100) if previous > 0 else 0

    st.markdown(f"""
    - **Current momentum**: {"Increasing 📈" if growth > 0 else "Declining 📉"}
    - **Month-on-Month change**: **{growth:.2f}%**
    - **Forecast outlook**: {"Positive growth" if forecast.mean() > latest else "Potential slowdown"}
    """)

    # ================== CLUSTERING ==================
    st.subheader("🧠 District Segmentation (ML)")

    cluster_df = (
        df_state
        .groupby("district")[["age_0_5", "age_5_17", "age_18_plus"]]
        .sum()
    )

    if len(cluster_df) >= 3:
        scaler = StandardScaler()
        scaled = scaler.fit_transform(cluster_df)
        kmeans = KMeans(n_clusters=3, random_state=42, n_init=10)
        cluster_df["cluster"] = kmeans.fit_predict(scaled)

        fig2, ax2 = plt.subplots(figsize=(8, 5))
        sns.scatterplot(
            x=cluster_df["age_18_plus"],
            y=cluster_df["age_0_5"],
            hue=cluster_df["cluster"],
            palette="Set2",
            ax=ax2
        )
        st.pyplot(fig2, use_container_width=True)
    else:
        st.info("Not enough districts for clustering.")

    # ================== DOWNLOAD ==================
    st.subheader("⬇️ Download Cleaned Data")
    st.download_button(
        "Download Cleaned CSV",
        data=df.to_csv(index=False),
        file_name="aadhaar_clean_final.csv",
        mime="text/csv"
    )

# ================== TAB 2 ==================
with tab2:
    st.subheader("🧪 Data Quality Report")

    col1, col2, col3 = st.columns(3)
    col1.metric("Total Records", len(df))
    col2.metric("Unique States", df["state"].nunique())
    col3.metric("Unique Districts", df["district"].nunique())

    st.divider()
    st.dataframe(df.isna().sum())
    st.dataframe(df.head(20), use_container_width=True)

st.caption(
    "End-to-end Government Grade Data Science Project | Cleaning • ML • Forecasting • Explainability"
)
